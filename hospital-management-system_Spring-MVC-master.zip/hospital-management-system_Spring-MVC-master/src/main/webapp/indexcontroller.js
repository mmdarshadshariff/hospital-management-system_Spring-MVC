var index_app = angular.module('myApp', []);
index_app.controller('myCtrl', function($scope, $http) {

	$scope.patient_insert = function() {
$scope.temp=false;
		$http.get(
				"/HospitalManagement/patientinsert/" + $scope.patient_id + "/"
						+ $scope.patient_name + "/" + $scope.patient_age)
				.success(function(response) {
					alert("Patient Account created");
					document.getElementById("p_id").value = "";
					document.getElementById("p_name").value = "";
					document.getElementById("p_age").value = "";

				});
	}

	$scope.patient_update = function() {

		$http.get(
				"/HospitalManagement/patientupdate/" + $scope.patient_name + "/"
						+ $scope.patient_age + "/" + $scope.patient_id)
				.success(function(response) {
					alert("Patient Account Updated");
					document.getElementById("p_id").value = "";
					document.getElementById("p_name").value = "";
					document.getElementById("p_age").value = "";

				});
	}

	$scope.patient_delete = function() {

		$http.get("/HospitalManagement/patientdelete/" + $scope.patient_id)
				.success(function(response) {
					alert("Patient Account Deleted");
					document.getElementById("p_id").value = "";
					document.getElementById("p_name").value = "";
					document.getElementById("p_age").value = "";

				});
	}

	$scope.patient_select = function() {

		$http.get("/HospitalManagement/patientid/" + $scope.patient_id).success(
				function(response) {
					$scope.temp=true;
					$scope.result = response;

				});
	}
	$scope.patient_retrieve = function()

	{

		$http.get("/HospitalManagement/displayall/")

		.success(function(response)

		{
			$scope.temp=true;
			$scope.result = response;

		});

	}

});