package com.training.DAO;

import java.util.List;

import com.training.model.Patients;

public interface PatientsDAO {

	   public List<Patients> getPatient(Integer id);
	   
	   public void updatePatient(Patients pt);
	   public void postPatient(Patients pt);
	   public void deletePatient(Integer id);
	   public List<Patients> getAllPatients();
	   }
